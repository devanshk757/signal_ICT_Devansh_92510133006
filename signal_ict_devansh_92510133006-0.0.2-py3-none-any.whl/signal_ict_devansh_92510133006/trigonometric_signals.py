import numpy as np
import matplotlib.pyplot as plt

def sine_wave(A, f, phi, t):
    """Generate sine wave"""
    signal = A * np.sin(2 * np.pi * f * t + phi)
    return signal

def cosine_wave(A, f, phi, t):
    """Generate cosine wave"""
    signal = A * np.cos(2 * np.pi * f * t + phi)
    return signal

def exponential_signal(A, a, t):
    """Generate exponential signal"""
    signal = A * np.exp(a * t)
    return signal
